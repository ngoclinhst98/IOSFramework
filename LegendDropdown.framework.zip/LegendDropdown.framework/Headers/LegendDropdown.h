//
//  LegendDropdown.h
//  LegendDropdown
//
//  Created by Nguyễn Ngọc Linh on 8/8/23.
//

#import <Foundation/Foundation.h>

//! Project version number for LegendDropdown.
FOUNDATION_EXPORT double LegendDropdownVersionNumber;

//! Project version string for LegendDropdown.
FOUNDATION_EXPORT const unsigned char LegendDropdownVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LegendDropdown/PublicHeader.h>
